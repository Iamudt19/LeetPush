var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(function() {
  "use strict";
  const STORAGE_KEYS = {
    CONFIG: "leetpush_config"
  };
  async function getConfig() {
    const result = await chrome.storage.local.get(STORAGE_KEYS.CONFIG);
    return result[STORAGE_KEYS.CONFIG] ?? null;
  }
  const PREFIX = "[LeetPush]";
  function sanitize(arg) {
    if (typeof arg === "string") {
      return arg.replace(/Bearer\s+[A-Za-z0-9_.~+-]+/gi, "Bearer [REDACTED]").replace(/gh[pousr]_[A-Za-z0-9_]{20,}/g, "[REDACTED_GH_TOKEN]");
    }
    if (typeof arg === "object" && arg !== null) {
      if (Array.isArray(arg)) {
        return arg.map(sanitize);
      }
      const cleanObj = {};
      for (const [key, value] of Object.entries(arg)) {
        const lower = key.toLowerCase();
        if (lower.includes("token") || lower.includes("secret") || lower.includes("auth") || lower.includes("password")) {
          cleanObj[key] = "[REDACTED]";
        } else {
          cleanObj[key] = sanitize(value);
        }
      }
      return cleanObj;
    }
    return arg;
  }
  const logger = {
    async debug(...args) {
      try {
        const config = await getConfig();
        if (config == null ? void 0 : config.debugMode) {
          const sanitized = args.map(sanitize);
          console.debug(PREFIX, ...sanitized);
        }
      } catch {
      }
    },
    info(...args) {
      const sanitized = args.map(sanitize);
      console.info(PREFIX, ...sanitized);
    },
    warn(...args) {
      const sanitized = args.map(sanitize);
      console.warn(PREFIX, ...sanitized);
    },
    error(...args) {
      const sanitized = args.map(sanitize);
      console.error(PREFIX, ...sanitized);
    }
  };
  const problemCache = /* @__PURE__ */ new Map();
  function htmlToMarkdown(html) {
    if (!html) return "";
    return html.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_, code) => {
      const cleanCode = code.replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();
      return `

\`\`\`text
${cleanCode}
\`\`\`

`;
    }).replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`").replace(/<(?:strong|b)[^>]*>(.*?)<\/(?:strong|b)>/gi, "**$1**").replace(/<(?:em|i)[^>]*>(.*?)<\/(?:em|i)>/gi, "*$1*").replace(/<sup[^>]*>(.*?)<\/sup>/gi, "^$1").replace(/<sub[^>]*>(.*?)<\/sub>/gi, "_$1").replace(/<li[^>]*>(.*?)<\/li>/gi, "- $1\n").replace(/<p[^>]*>/gi, "\n\n").replace(/<\/p>/gi, "").replace(/<br\s*\/?>/gi, "\n").replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/<[^>]+>/g, "").replace(/\n{3,}/g, "\n\n").trim();
  }
  function extractSlugFromUrl(url = window.location.href) {
    try {
      const parsed = new URL(url);
      const match = parsed.pathname.match(/\/problems\/([^/]+)/);
      return match ? match[1] : null;
    } catch {
      return null;
    }
  }
  function parseProblemTitleString(raw) {
    const trimmed = raw.trim();
    const match = trimmed.match(/^(\d+)\s*[\.\-:]\s*(.+)$/);
    if (match && match[1] && match[2]) {
      return {
        number: parseInt(match[1], 10),
        title: match[2].trim()
      };
    }
    return {
      number: 0,
      title: trimmed
    };
  }
  function extractProblemInfoFromDom(slug) {
    var _a;
    let number = 0;
    let title = slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    let difficulty = "Unknown";
    const topics = [];
    const titleSelectors = [
      'div[data-cy="question-title"]',
      'a[href*="/problems/' + slug + '"]',
      ".text-title-large",
      'h4[data-cypress="QuestionTitle"]',
      '[class*="title__"]',
      "div.flex.items-start.justify-between h1",
      "div.flex.items-start.justify-between a"
    ];
    for (const selector of titleSelectors) {
      const el = document.querySelector(selector);
      if (el && el.textContent) {
        const parsed = parseProblemTitleString(el.textContent);
        if (parsed.number > 0) {
          number = parsed.number;
          title = parsed.title;
          break;
        }
      }
    }
    const diffSelectors = [
      'div[class*="text-difficulty-"]',
      'div[class*="text-olive"]',
      // Easy
      'div[class*="text-yellow"]',
      // Medium
      'div[class*="text-pink"]',
      // Hard
      "span[data-degree]",
      "div[data-difficulty]"
    ];
    for (const sel of diffSelectors) {
      const el = document.querySelector(sel);
      const text = (_a = el == null ? void 0 : el.textContent) == null ? void 0 : _a.trim().toLowerCase();
      if (text == null ? void 0 : text.includes("easy")) {
        difficulty = "Easy";
        break;
      } else if (text == null ? void 0 : text.includes("medium")) {
        difficulty = "Medium";
        break;
      } else if (text == null ? void 0 : text.includes("hard")) {
        difficulty = "Hard";
        break;
      }
    }
    const tagElements = document.querySelectorAll('a[href*="/tag/"]');
    tagElements.forEach((el) => {
      var _a2;
      const tag = (_a2 = el.textContent) == null ? void 0 : _a2.trim();
      if (tag && !topics.includes(tag)) {
        topics.push(tag);
      }
    });
    let description = void 0;
    const descEl = document.querySelector(
      '[data-track-load="description_content"], div[class*="elfjS"], .question-content'
    );
    if (descEl && descEl.innerHTML) {
      description = htmlToMarkdown(descEl.innerHTML);
    }
    return {
      number,
      title,
      slug,
      url: `https://leetcode.com/problems/${slug}/`,
      difficulty,
      topics,
      description
    };
  }
  async function fetchProblemInfoViaGraphQL(slug) {
    var _a;
    if (problemCache.has(slug)) {
      return problemCache.get(slug);
    }
    const query = `
    query questionData($titleSlug: String!) {
      question(titleSlug: $titleSlug) {
        questionId
        questionFrontendId
        title
        titleSlug
        content
        difficulty
        topicTags {
          name
          slug
        }
        companyTagStats
      }
    }
  `;
    try {
      const csrfMatch = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
      const headers = {
        "Content-Type": "application/json"
      };
      if (csrfMatch && csrfMatch[1]) {
        headers["x-csrftoken"] = csrfMatch[1];
      }
      const res = await fetch("https://leetcode.com/graphql", {
        method: "POST",
        headers,
        body: JSON.stringify({
          query,
          variables: { titleSlug: slug }
        })
      });
      if (!res.ok) {
        logger.warn(`GraphQL question query returned HTTP ${res.status}`);
        return null;
      }
      const data = await res.json();
      const q = (_a = data == null ? void 0 : data.data) == null ? void 0 : _a.question;
      if (!q) return null;
      let companyTags = [];
      if (q.companyTagStats) {
        try {
          const parsed = typeof q.companyTagStats === "string" ? JSON.parse(q.companyTagStats) : q.companyTagStats;
          const allTags = Object.values(parsed).flat();
          companyTags = [...new Set(allTags.map((t) => t.name))].sort();
        } catch {
          companyTags = [];
        }
      }
      const info = {
        number: parseInt(q.questionFrontendId, 10) || 0,
        title: q.title || slug,
        slug: q.titleSlug || slug,
        url: `https://leetcode.com/problems/${q.titleSlug || slug}/`,
        difficulty: q.difficulty || "Unknown",
        topics: (q.topicTags || []).map((t) => t.name),
        companyTags,
        description: q.content ? htmlToMarkdown(q.content) : void 0
      };
      problemCache.set(slug, info);
      return info;
    } catch (err) {
      logger.warn("Failed to fetch problem info via GraphQL, using fallback", err);
      return null;
    }
  }
  async function resolveProblemInfo(slug) {
    const cached = problemCache.get(slug);
    if (cached) return cached;
    const gqlInfo = await fetchProblemInfoViaGraphQL(slug);
    if (gqlInfo && gqlInfo.number > 0) {
      return gqlInfo;
    }
    const domInfo = extractProblemInfoFromDom(slug);
    if (gqlInfo) {
      return {
        ...gqlInfo,
        number: gqlInfo.number > 0 ? gqlInfo.number : domInfo.number,
        difficulty: gqlInfo.difficulty !== "Unknown" ? gqlInfo.difficulty : domInfo.difficulty,
        topics: gqlInfo.topics.length > 0 ? gqlInfo.topics : domInfo.topics,
        description: gqlInfo.description || domInfo.description
      };
    }
    return domInfo;
  }
  function getCsrfToken() {
    try {
      const match = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
      return match ? match[1] : "";
    } catch {
      return "";
    }
  }
  async function fetchLatestAcceptedSubmissionForSlug(slug) {
    var _a;
    const query = `
    query recentAcSubmissions($limit: Int!) {
      recentAcSubmissionList(limit: $limit) {
        id
        title
        titleSlug
        timestamp
      }
    }
  `;
    try {
      const csrf = getCsrfToken();
      const headers = {
        "Content-Type": "application/json"
      };
      if (csrf) headers["x-csrftoken"] = csrf;
      const res = await fetch("https://leetcode.com/graphql", {
        method: "POST",
        headers,
        credentials: "include",
        body: JSON.stringify({
          query,
          variables: { limit: 10 }
        })
      });
      if (!res.ok) {
        logger.warn(`recentAcSubmissionList query returned HTTP ${res.status}`);
        return null;
      }
      const data = await res.json();
      const list = (_a = data == null ? void 0 : data.data) == null ? void 0 : _a.recentAcSubmissionList;
      if (!Array.isArray(list)) return null;
      const match = list.find((item) => item.titleSlug === slug);
      if (match && match.id) {
        return {
          id: String(match.id),
          timestamp: parseInt(match.timestamp, 10) * 1e3 || Date.now()
        };
      }
      return null;
    } catch (err) {
      logger.warn("Failed to fetch recent accepted submissions list", err);
      return null;
    }
  }
  async function fetchSubmittedCodeBySubmissionId(submissionId) {
    var _a, _b, _c;
    const numericId = typeof submissionId === "string" ? parseInt(submissionId, 10) : submissionId;
    if (!numericId || isNaN(numericId)) {
      logger.warn(`Invalid submission ID for code extraction: ${submissionId}`);
      return null;
    }
    const query = `
    query submissionDetails($submissionId: Int!) {
      submissionDetail(submissionId: $submissionId) {
        code
        timestamp
        statusDisplay
        lang {
          name
          verboseName
        }
        runtimeDisplay
        memoryDisplay
        runtimePercentile
        memoryPercentile
      }
    }
  `;
    try {
      const csrf = getCsrfToken();
      const headers = {
        "Content-Type": "application/json"
      };
      if (csrf) headers["x-csrftoken"] = csrf;
      const res = await fetch("https://leetcode.com/graphql", {
        method: "POST",
        headers,
        credentials: "include",
        body: JSON.stringify({
          query,
          variables: { submissionId: numericId }
        })
      });
      if (!res.ok) {
        logger.warn(`GraphQL submissionDetail request failed with HTTP ${res.status}`);
        return null;
      }
      const json = await res.json();
      const detail = (_a = json == null ? void 0 : json.data) == null ? void 0 : _a.submissionDetail;
      if (!detail || !detail.code) {
        logger.warn("GraphQL submissionDetail returned empty code", json);
        return null;
      }
      return {
        submissionId: String(numericId),
        code: detail.code,
        lang: ((_b = detail.lang) == null ? void 0 : _b.verboseName) || ((_c = detail.lang) == null ? void 0 : _c.name) || "",
        runtime: detail.runtimeDisplay || "",
        memory: detail.memoryDisplay || "",
        statusDisplay: detail.statusDisplay || ""
      };
    } catch (err) {
      logger.error("Failed to fetch submitted code via GraphQL", err);
      return null;
    }
  }
  function extractCodeFromMonacoDom() {
    try {
      const lines = document.querySelectorAll(".view-lines .view-line");
      if (lines && lines.length > 0) {
        const code = Array.from(lines).map((l) => l.textContent || "").join("\n");
        if (code.trim().length > 0) return code;
      }
    } catch {
    }
    return null;
  }
  async function resolveSubmittedCode(submissionId, initialCode) {
    if (initialCode && initialCode.trim().length > 0) {
      return { code: initialCode };
    }
    if (submissionId) {
      const details = await fetchSubmittedCodeBySubmissionId(submissionId);
      if (details && details.code && details.code.trim().length > 0) {
        return {
          code: details.code,
          runtime: details.runtime,
          memory: details.memory,
          language: details.lang
        };
      }
    }
    const monacoCode = extractCodeFromMonacoDom();
    if (monacoCode && monacoCode.trim().length > 0) {
      logger.warn("Falling back to Monaco editor DOM for submitted code");
      return { code: monacoCode };
    }
    logger.error(
      `Could not retrieve submitted code for submission #${submissionId}.`
    );
    return null;
  }
  const LANGUAGE_MAP = {
    // Python
    python: { name: "Python", extension: ".py", defaultFilename: "solution.py", monacoLanguage: "python" },
    python3: { name: "Python3", extension: ".py", defaultFilename: "solution.py", monacoLanguage: "python" },
    py: { name: "Python3", extension: ".py", defaultFilename: "solution.py", monacoLanguage: "python" },
    // C++
    cpp: { name: "C++", extension: ".cpp", defaultFilename: "solution.cpp", monacoLanguage: "cpp" },
    "c++": { name: "C++", extension: ".cpp", defaultFilename: "solution.cpp", monacoLanguage: "cpp" },
    // Java
    java: { name: "Java", extension: ".java", defaultFilename: "Solution.java", monacoLanguage: "java" },
    // C
    c: { name: "C", extension: ".c", defaultFilename: "solution.c", monacoLanguage: "c" },
    // C#
    csharp: { name: "C#", extension: ".cs", defaultFilename: "Solution.cs", monacoLanguage: "csharp" },
    "c#": { name: "C#", extension: ".cs", defaultFilename: "Solution.cs", monacoLanguage: "csharp" },
    cs: { name: "C#", extension: ".cs", defaultFilename: "Solution.cs", monacoLanguage: "csharp" },
    // JavaScript
    javascript: { name: "JavaScript", extension: ".js", defaultFilename: "solution.js", monacoLanguage: "javascript" },
    js: { name: "JavaScript", extension: ".js", defaultFilename: "solution.js", monacoLanguage: "javascript" },
    // TypeScript
    typescript: { name: "TypeScript", extension: ".ts", defaultFilename: "solution.ts", monacoLanguage: "typescript" },
    ts: { name: "TypeScript", extension: ".ts", defaultFilename: "solution.ts", monacoLanguage: "typescript" },
    // PHP
    php: { name: "PHP", extension: ".php", defaultFilename: "solution.php", monacoLanguage: "php" },
    // Swift
    swift: { name: "Swift", extension: ".swift", defaultFilename: "solution.swift", monacoLanguage: "swift" },
    // Kotlin
    kotlin: { name: "Kotlin", extension: ".kt", defaultFilename: "solution.kt", monacoLanguage: "kotlin" },
    kt: { name: "Kotlin", extension: ".kt", defaultFilename: "solution.kt", monacoLanguage: "kotlin" },
    // Dart
    dart: { name: "Dart", extension: ".dart", defaultFilename: "solution.dart", monacoLanguage: "dart" },
    // Go
    golang: { name: "Go", extension: ".go", defaultFilename: "solution.go", monacoLanguage: "go" },
    go: { name: "Go", extension: ".go", defaultFilename: "solution.go", monacoLanguage: "go" },
    // Ruby
    ruby: { name: "Ruby", extension: ".rb", defaultFilename: "solution.rb", monacoLanguage: "ruby" },
    rb: { name: "Ruby", extension: ".rb", defaultFilename: "solution.rb", monacoLanguage: "ruby" },
    // Scala
    scala: { name: "Scala", extension: ".scala", defaultFilename: "solution.scala", monacoLanguage: "scala" },
    // Rust
    rust: { name: "Rust", extension: ".rs", defaultFilename: "solution.rs", monacoLanguage: "rust" },
    rs: { name: "Rust", extension: ".rs", defaultFilename: "solution.rs", monacoLanguage: "rust" },
    // Racket
    racket: { name: "Racket", extension: ".rkt", defaultFilename: "solution.rkt", monacoLanguage: "racket" },
    rkt: { name: "Racket", extension: ".rkt", defaultFilename: "solution.rkt", monacoLanguage: "racket" },
    // Erlang
    erlang: { name: "Erlang", extension: ".erl", defaultFilename: "solution.erl", monacoLanguage: "erlang" },
    erl: { name: "Erlang", extension: ".erl", defaultFilename: "solution.erl", monacoLanguage: "erlang" },
    // Elixir
    elixir: { name: "Elixir", extension: ".ex", defaultFilename: "solution.ex", monacoLanguage: "elixir" },
    ex: { name: "Elixir", extension: ".ex", defaultFilename: "solution.ex", monacoLanguage: "elixir" }
  };
  function getLanguageMeta(rawLang) {
    if (!rawLang) {
      return { name: "Text", extension: ".txt", defaultFilename: "solution.txt", monacoLanguage: "plaintext" };
    }
    const clean = rawLang.trim().toLowerCase();
    const meta = LANGUAGE_MAP[clean];
    if (meta) return meta;
    const safeName = rawLang.charAt(0).toUpperCase() + rawLang.slice(1);
    return {
      name: safeName,
      extension: `.${clean}`,
      defaultFilename: `solution.${clean}`,
      monacoLanguage: clean
    };
  }
  function extractContestSlugFromUrl(url = window.location.href) {
    try {
      const match = url.match(/\/contest\/([^/]+)\/problems\//);
      return match ? match[1] : null;
    } catch {
      return null;
    }
  }
  class SubmissionDetector {
    constructor(onAccepted) {
      __publicField(this, "onAcceptedCallback");
      __publicField(this, "processedIds", /* @__PURE__ */ new Set());
      __publicField(this, "domObserver", null);
      __publicField(this, "isRunning", false);
      __publicField(this, "isPollingAfterSubmit", false);
      __publicField(this, "handleNetworkEvent", async (event) => {
        try {
          const customEvent = event;
          const detail = customEvent.detail;
          if (!detail || !detail.data) return;
          const data = detail.data;
          logger.info("Received network submission event:", detail.source);
          if (data.status_msg === "Accepted" || data.state === "SUCCESS" || data.status_code === 10) {
            const submissionId = String(
              data.submission_id || this.extractSubmissionIdFromUrl(detail.url) || ""
            );
            if (submissionId) {
              await this.handleAcceptedSubmission({
                submissionId,
                code: data.code,
                lang: data.lang,
                runtime: data.status_runtime || data.runtime || "",
                memory: data.status_memory || data.memory || ""
              });
            } else {
              this.triggerActivePollForAccepted();
            }
          }
        } catch (err) {
          logger.error("Error processing network submission event", err);
        }
      });
      this.onAcceptedCallback = onAccepted;
    }
    /**
     * Start listening for submissions via network events, DOM observer, and click tracking.
     */
    start() {
      if (this.isRunning) return;
      this.isRunning = true;
      this.setupEventListener();
      this.setupDomObserver();
      this.setupSubmitButtonListener();
      logger.info("Submission detector active with multi-layer detection");
    }
    /**
     * Stop detection and clean up observers and listeners.
     */
    stop() {
      this.isRunning = false;
      if (this.domObserver) {
        this.domObserver.disconnect();
        this.domObserver = null;
      }
      window.removeEventListener("LEETPUSH_SUBMISSION_EVENT", this.handleNetworkEvent);
    }
    /**
     * Listen for events dispatched from the main-world interceptor script.
     */
    setupEventListener() {
      window.addEventListener("LEETPUSH_SUBMISSION_EVENT", this.handleNetworkEvent);
    }
    /**
     * Track clicks on the "Submit" button to activate rapid polling for the result.
     */
    setupSubmitButtonListener() {
      document.addEventListener(
        "click",
        (e) => {
          var _a;
          const target = e.target;
          if (!target) return;
          const submitBtn = target.closest(
            '[data-e2e-locator="console-submit-button"], button[class*="submit"], button'
          );
          if (submitBtn && ((_a = submitBtn.textContent) == null ? void 0 : _a.trim().toLowerCase().includes("submit"))) {
            logger.info("User clicked LeetCode Submit button. Starting active watcher...");
            this.triggerActivePollForAccepted();
          }
        },
        true
      );
    }
    /**
     * Active polling: runs after Submit is clicked or when Accepted is detected in DOM.
     * Polls LeetCode GraphQL recentAcSubmissionList every 1.5s for up to 25 seconds.
     */
    triggerActivePollForAccepted() {
      if (this.isPollingAfterSubmit) return;
      this.isPollingAfterSubmit = true;
      const slug = extractSlugFromUrl();
      if (!slug) {
        this.isPollingAfterSubmit = false;
        return;
      }
      const startTime = Date.now();
      let attempts = 0;
      const maxAttempts = 15;
      const interval = window.setInterval(async () => {
        attempts++;
        logger.debug(`Polling for accepted submission (attempt ${attempts}/${maxAttempts})...`);
        const domAccepted = this.isDomShowingAccepted();
        const latest = await fetchLatestAcceptedSubmissionForSlug(slug);
        if (latest && latest.id && !this.processedIds.has(latest.id)) {
          if (latest.timestamp > startTime - 18e4) {
            window.clearInterval(interval);
            this.isPollingAfterSubmit = false;
            logger.info(`Detected fresh accepted submission via GraphQL: #${latest.id}`);
            await this.handleAcceptedSubmission({ submissionId: latest.id });
            return;
          }
        }
        const urlMatch = window.location.href.match(/\/submissions\/(\d+)/);
        if (urlMatch && urlMatch[1] && !this.processedIds.has(urlMatch[1]) && domAccepted) {
          window.clearInterval(interval);
          this.isPollingAfterSubmit = false;
          logger.info(`Detected accepted submission via URL match: #${urlMatch[1]}`);
          await this.handleAcceptedSubmission({ submissionId: urlMatch[1] });
          return;
        }
        if (attempts >= maxAttempts) {
          window.clearInterval(interval);
          this.isPollingAfterSubmit = false;
          logger.debug("Active submission polling ended");
        }
      }, 1500);
    }
    /**
     * MutationObserver monitoring DOM for the "Accepted" text badge.
     * Safe to run at document_start (uses documentElement if body is not ready).
     */
    setupDomObserver() {
      let debounceTimer = null;
      this.domObserver = new MutationObserver(() => {
        if (debounceTimer) window.clearTimeout(debounceTimer);
        debounceTimer = window.setTimeout(() => {
          this.checkDomForAccepted();
        }, 600);
      });
      const targetNode = document.body || document.documentElement;
      if (targetNode) {
        this.domObserver.observe(targetNode, {
          childList: true,
          subtree: true
        });
      } else {
        document.addEventListener("DOMContentLoaded", () => {
          if (this.domObserver && document.body) {
            this.domObserver.observe(document.body, {
              childList: true,
              subtree: true
            });
          }
        });
      }
    }
    /**
     * Returns true if the DOM currently contains an "Accepted" verdict.
     */
    isDomShowingAccepted() {
      var _a, _b;
      const selectors = [
        '[data-e2e-locator="submission-result"]',
        'span[class*="text-green"]',
        'span[class*="text-olive"]',
        'div[class*="text-green"]',
        'div[class*="text-olive"]',
        'div[class*="text-sd-easy"]',
        "div.text-green-s"
      ];
      for (const sel of selectors) {
        const elements = document.querySelectorAll(sel);
        for (const el of Array.from(elements)) {
          if (((_a = el.textContent) == null ? void 0 : _a.trim()) === "Accepted") {
            return true;
          }
        }
      }
      const headers = document.querySelectorAll("h1, h2, h3, h4, span, div");
      for (let i = 0; i < Math.min(headers.length, 300); i++) {
        const text = (_b = headers[i].textContent) == null ? void 0 : _b.trim();
        if (text === "Accepted") {
          return true;
        }
      }
      return false;
    }
    /**
     * Scan DOM when mutation occurs.
     */
    async checkDomForAccepted() {
      if (!this.isDomShowingAccepted()) return;
      const urlMatch = window.location.href.match(/\/submissions\/(\d+)/);
      if (urlMatch && urlMatch[1] && !this.processedIds.has(urlMatch[1])) {
        await this.handleAcceptedSubmission({ submissionId: urlMatch[1] });
        return;
      }
      const links = document.querySelectorAll(
        'a[href*="/submissions/"], a[href*="/submissions/detail/"]'
      );
      for (const link of Array.from(links)) {
        const match = link.href.match(/\/submissions\/(?:detail\/)?(\d+)/);
        if (match && match[1] && !this.processedIds.has(match[1])) {
          await this.handleAcceptedSubmission({ submissionId: match[1] });
          return;
        }
      }
      this.triggerActivePollForAccepted();
    }
    /**
     * Parse submissionId from URL e.g. /submissions/detail/123456789/check/
     */
    extractSubmissionIdFromUrl(url) {
      const match = url.match(/\/submissions\/(?:detail\/)?(\d+)/);
      return match ? match[1] : null;
    }
    /**
     * Full pipeline when an accepted submission is detected:
     * 1. Dedup check
     * 2. Problem extraction
     * 3. Submitted code resolution
     * 4. Trigger callback
     */
    async handleAcceptedSubmission(raw) {
      const { submissionId } = raw;
      if (this.processedIds.has(submissionId)) {
        return;
      }
      this.processedIds.add(submissionId);
      logger.info(`Processing confirmed accepted submission: #${submissionId}`);
      const slug = extractSlugFromUrl();
      if (!slug) {
        logger.error(`Could not determine problem slug for submission #${submissionId}`);
        return;
      }
      const problem = await resolveProblemInfo(slug);
      const codeResult = await resolveSubmittedCode(submissionId, raw.code);
      if (!codeResult || !codeResult.code) {
        logger.error(`Failed to retrieve submitted code for #${submissionId}`);
        return;
      }
      let rawLang = raw.lang || codeResult.language || "";
      if (!rawLang) {
        const langBtn = document.querySelector('button[id*="headlessui-listbox-button"]');
        if (langBtn && langBtn.textContent) {
          rawLang = langBtn.textContent.trim();
        }
      }
      const langMeta = getLanguageMeta(rawLang);
      const acceptedSubmission = {
        submissionId,
        problem,
        language: langMeta.name,
        langSlug: rawLang,
        code: codeResult.code,
        runtime: raw.runtime || codeResult.runtime || "",
        memory: raw.memory || codeResult.memory || "",
        contestSlug: extractContestSlugFromUrl() ?? void 0,
        // Feature 10
        submittedAt: Date.now()
      };
      logger.info(`Ready to sync: #${problem.number} ${problem.title} [${langMeta.name}]`);
      this.onAcceptedCallback(acceptedSubmission);
    }
  }
  class LeetPushToast {
    constructor() {
      __publicField(this, "element", null);
      __publicField(this, "timeoutId", null);
    }
    show(message, type = "info", durationMs = 4e3) {
      if (!this.element) {
        this.createElement();
      }
      if (!this.element) return;
      if (this.timeoutId) {
        window.clearTimeout(this.timeoutId);
      }
      const icons = {
        info: "⚡",
        success: "✓",
        warn: "⚠️",
        error: "✕"
      };
      const colors = {
        info: { bg: "#1e293b", border: "#38bdf8", text: "#f8fafc" },
        success: { bg: "#064e3b", border: "#10b981", text: "#ecfdf5" },
        warn: { bg: "#451a03", border: "#f59e0b", text: "#fffbeb" },
        error: { bg: "#4c0519", border: "#f43f5e", text: "#fff1f2" }
      };
      const currentStyle = colors[type];
      this.element.style.background = currentStyle.bg;
      this.element.style.borderColor = currentStyle.border;
      this.element.style.color = currentStyle.text;
      this.element.innerHTML = `
      <div style="display:flex; align-items:center; gap:8px;">
        <span style="font-weight:700; font-size:14px;">LeetPush</span>
        <span style="font-size:14px;">${icons[type]}</span>
        <span style="font-size:13px; font-weight:500;">${message}</span>
      </div>
    `;
      this.element.style.opacity = "1";
      this.element.style.transform = "translateY(0)";
      this.timeoutId = window.setTimeout(() => {
        this.hide();
      }, durationMs);
    }
    hide() {
      if (this.element) {
        this.element.style.opacity = "0";
        this.element.style.transform = "translateY(16px)";
      }
    }
    createElement() {
      const el = document.createElement("div");
      el.id = "leetpush-status-toast";
      el.style.position = "fixed";
      el.style.bottom = "24px";
      el.style.right = "24px";
      el.style.zIndex = "999999";
      el.style.padding = "12px 18px";
      el.style.borderRadius = "8px";
      el.style.border = "1px solid #38bdf8";
      el.style.boxShadow = "0 10px 25px -5px rgba(0, 0, 0, 0.5), 0 8px 10px -6px rgba(0, 0, 0, 0.4)";
      el.style.fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      el.style.transition = "all 0.3s cubic-bezier(0.16, 1, 0.3, 1)";
      el.style.opacity = "0";
      el.style.transform = "translateY(16px)";
      el.style.pointerEvents = "none";
      document.body.appendChild(el);
      this.element = el;
    }
  }
  function showNotePanel(submission) {
    var _a, _b, _c, _d, _e;
    (_a = document.getElementById("leetpush-note-panel")) == null ? void 0 : _a.remove();
    const panel = document.createElement("div");
    panel.id = "leetpush-note-panel";
    Object.assign(panel.style, {
      position: "fixed",
      bottom: "90px",
      right: "24px",
      zIndex: "999998",
      width: "340px",
      background: "#0f172a",
      border: "1px solid #334155",
      borderRadius: "12px",
      boxShadow: "0 20px 40px -10px rgba(0,0,0,0.7)",
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      fontSize: "13px",
      color: "#f8fafc",
      overflow: "hidden",
      opacity: "0",
      transform: "translateY(20px) scale(0.97)",
      transition: "all 0.3s cubic-bezier(0.16, 1, 0.3, 1)"
    });
    panel.innerHTML = `
    <div style="background:#1e293b; padding:10px 14px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #334155;">
      <div style="display:flex; align-items:center; gap:6px; font-weight:700;">
        <span style="font-size:14px;">⚡</span> LeetPush – Add Details
      </div>
      <button id="lp-panel-close" style="background:none; border:none; color:#94a3b8; cursor:pointer; font-size:16px; padding:2px 6px; border-radius:4px;" title="Dismiss">✕</button>
    </div>
    <div style="padding:12px 14px; display:flex; flex-direction:column; gap:10px;">
      <div style="color:#94a3b8; font-size:11px; font-weight:600; letter-spacing:0.5px; text-transform:uppercase;">
        #${submission.problem.number} ${submission.problem.title}
      </div>

      <div style="display:flex; flex-direction:column; gap:4px;">
        <label style="font-size:12px; color:#94a3b8;" for="lp-complexity-input">Complexity (optional)</label>
        <input
          id="lp-complexity-input"
          type="text"
          placeholder="e.g. Time: O(n log n) | Space: O(n)"
          style="background:#1e293b; border:1px solid #334155; border-radius:6px; color:#f8fafc; font-size:12px; padding:7px 10px; outline:none; width:100%; box-sizing:border-box;"
        />
      </div>

      <div style="display:flex; flex-direction:column; gap:4px;">
        <label style="font-size:12px; color:#94a3b8;" for="lp-notes-input">Approach Note (optional)</label>
        <textarea
          id="lp-notes-input"
          placeholder="Briefly describe your approach, key insights, or algorithm used..."
          rows="3"
          style="background:#1e293b; border:1px solid #334155; border-radius:6px; color:#f8fafc; font-size:12px; padding:7px 10px; outline:none; width:100%; box-sizing:border-box; resize:vertical; font-family:inherit;"
        ></textarea>
      </div>

      <div style="display:flex; gap:8px; align-items:center;">
        <button id="lp-save-note" style="background:#38bdf8; color:#0f172a; border:none; border-radius:6px; font-size:12px; font-weight:700; padding:7px 14px; cursor:pointer; flex:1; transition:background 0.2s;">
          Save
        </button>
        <button id="lp-skip-note" style="background:#334155; color:#94a3b8; border:none; border-radius:6px; font-size:12px; font-weight:600; padding:7px 10px; cursor:pointer; transition:background 0.2s;">
          Skip
        </button>
        <button id="lp-block-problem" style="background:transparent; border:1px solid #f43f5e33; color:#f43f5e; border-radius:6px; font-size:11px; font-weight:600; padding:7px 10px; cursor:pointer; white-space:nowrap;" title="Never push this problem again">
          ⊘ Skip Problem
        </button>
      </div>
    </div>
  `;
    document.body.appendChild(panel);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        panel.style.opacity = "1";
        panel.style.transform = "translateY(0) scale(1)";
      });
    });
    const closePanel = () => {
      panel.style.opacity = "0";
      panel.style.transform = "translateY(20px) scale(0.97)";
      setTimeout(() => panel.remove(), 300);
    };
    (_b = document.getElementById("lp-panel-close")) == null ? void 0 : _b.addEventListener("click", closePanel);
    (_c = document.getElementById("lp-skip-note")) == null ? void 0 : _c.addEventListener("click", closePanel);
    (_d = document.getElementById("lp-save-note")) == null ? void 0 : _d.addEventListener("click", async () => {
      var _a2, _b2;
      const complexity = (_a2 = document.getElementById("lp-complexity-input")) == null ? void 0 : _a2.value.trim();
      const notes = (_b2 = document.getElementById("lp-notes-input")) == null ? void 0 : _b2.value.trim();
      if (complexity || notes) {
        try {
          await chrome.runtime.sendMessage({
            type: "UPDATE_SUBMISSION_NOTE",
            payload: { submissionId: submission.submissionId, notes, complexity }
          });
          const saveBtn = document.getElementById("lp-save-note");
          saveBtn.textContent = "✓ Saved!";
          saveBtn.style.background = "#10b981";
          setTimeout(closePanel, 900);
        } catch (err) {
          logger.warn("Failed to save note", err);
          closePanel();
        }
      } else {
        closePanel();
      }
    });
    (_e = document.getElementById("lp-block-problem")) == null ? void 0 : _e.addEventListener("click", async () => {
      try {
        await chrome.runtime.sendMessage({
          type: "SKIP_PROBLEM",
          payload: { slug: submission.problem.slug }
        });
        const btn = document.getElementById("lp-block-problem");
        btn.textContent = "✓ Problem Skipped";
        btn.style.color = "#10b981";
        btn.style.borderColor = "#10b981";
        setTimeout(closePanel, 1500);
      } catch (err) {
        logger.warn("Failed to skip problem", err);
      }
    });
    setTimeout(closePanel, 45e3);
  }
  function setupSpaNavigation(onNavigate) {
    let lastUrl = window.location.href;
    const checkUrlChange = () => {
      const currentUrl = window.location.href;
      if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        logger.info("SPA navigation detected:", currentUrl);
        onNavigate();
      }
    };
    const originalPushState = history.pushState;
    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      checkUrlChange();
    };
    const originalReplaceState = history.replaceState;
    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      checkUrlChange();
    };
    window.addEventListener("popstate", checkUrlChange);
  }
  const toast = new LeetPushToast();
  function init() {
    logger.info("LeetPush content script loaded on LeetCode");
    const detector = new SubmissionDetector(async (submission) => {
      var _a;
      logger.info(`Sending accepted submission #${submission.submissionId} to background`);
      toast.show(`Accepted: #${submission.problem.number} ${submission.problem.title}. Syncing to GitHub...`, "info", 5e3);
      try {
        const message = {
          type: "SUBMISSION_ACCEPTED",
          payload: { submission }
        };
        const response = await chrome.runtime.sendMessage(message);
        if ((response == null ? void 0 : response.status) === "synced") {
          toast.show(`✓ Synced #${submission.problem.number} ${submission.problem.title} to GitHub`, "success", 4e3);
          setTimeout(() => showNotePanel(submission), 1200);
        } else if ((response == null ? void 0 : response.status) === "skipped") {
          toast.show(`✓ Solution for #${submission.problem.number} already exists on GitHub`, "info", 4e3);
        } else if ((response == null ? void 0 : response.status) === "failed") {
          if ((_a = response.error) == null ? void 0 : _a.includes("skip list")) {
            toast.show(`⊘ #${submission.problem.number} is on your skip list — not pushed`, "warn", 5e3);
          } else {
            toast.show(`✕ Sync failed: ${response.error || "Check extension popup"}`, "error", 6e3);
          }
        }
      } catch (err) {
        logger.error("Failed to communicate with LeetPush service worker", err);
        toast.show(`⚠️ Background worker unavailable: ${(err == null ? void 0 : err.message) || "Queued for retry"}`, "warn", 5e3);
      }
    });
    detector.start();
    setupSpaNavigation(() => {
      var _a;
      logger.debug("URL updated, detector active for current page");
      (_a = document.getElementById("leetpush-note-panel")) == null ? void 0 : _a.remove();
    });
    window.addEventListener("beforeunload", () => {
      detector.stop();
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
