import{i as G,m as L,h as K,a as z,b as J,c as V,d as F,g as _,e as E,r as T,u as v,f as X,j as Z,k as ee,l as te,n as H,o as N}from"./chunks/storage-YeR1Sdfg.js";import{G as O,d as U}from"./chunks/github-api-CJY-jUMd.js";import{g as j,a as ne}from"./chunks/language-BFafBiqH.js";import{l}from"./chunks/logger-C_F-_EwR.js";function D(e){return e?e.toLowerCase().trim().replace(/[/\\:*?"<>|#]/g,"").replace(/[^\w\s-]/g,"").replace(/[\s_]+/g,"-").replace(/^-+|-+$/g,""):""}function B(e){return e<0?"0000":String(e).padStart(4,"0")}function Y(e,t){return e.replace(/\{number\}/g,String(t.number)).replace(/\{padded_number\}/g,B(t.number)).replace(/\{title\}/g,t.title).replace(/\{slug\}/g,t.slug).replace(/\{language\}/g,t.language).replace(/\{filename\}/g,t.filename||"")}function ae(){return`name: LeetPush – README Sync

on:
  push:
    branches: [ main, master ]
    paths:
      - 'solutions/**'
      - 'contests/**'

jobs:
  verify-solutions:
    name: Verify Solutions Index
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Count solution files
        id: count
        run: |
          TOTAL=$(find solutions contests -type f \\( -name "*.py" -o -name "*.java" -o -name "*.cpp" -o -name "*.ts" -o -name "*.go" -o -name "*.rs" -o -name "*.js" -o -name "*.c" -o -name "*.cs" \\) 2>/dev/null | wc -l)
          echo "total=\${TOTAL}" >> "\${GITHUB_OUTPUT}"

      - name: Post summary
        run: |
          echo "## LeetPush Solution Summary" >> $GITHUB_STEP_SUMMARY
          echo "" >> $GITHUB_STEP_SUMMARY
          echo "✅ \${{ steps.count.outputs.total }} solution files tracked." >> $GITHUB_STEP_SUMMARY
          echo "" >> $GITHUB_STEP_SUMMARY
          echo "_Automatically maintained by [LeetPush](https://github.com/Iamudt19/Chaptr)_" >> $GITHUB_STEP_SUMMARY
`}async function oe(e){const{token:t,owner:n,repo:o,branch:a}=e,r=new O(t),i=".github/workflows/leetpush-sync.yml";try{const d=await r.getFile(n,o,i,a),f=ae();await r.createOrUpdateFile({owner:n,repo:o,path:i,content:f,message:"ci: add LeetPush solution tracking workflow",branch:a,sha:d==null?void 0:d.sha}),l.info(`GitHub Actions workflow generated at ${i}`)}catch(d){l.warn("Failed to generate GitHub Actions workflow (non-fatal)",d)}}function re(e,t){const n=t.toLowerCase();return`${n==="python"||n==="python3"||n==="ruby"||n==="elixir"?"#":n==="sql"?"--":"//"} ${e}
`}function W(e,t,n){return!t||e.trimStart().startsWith("// Time:")||e.trimStart().startsWith("# Time:")?e:`${re(t,n)}${e}`}function ie(e){const{problem:t,language:n,runtime:o,memory:a,submittedAt:r}=e,i=new Date(r).toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"}),d=t.topics.length>0?t.topics.map(s=>`\`${s}\``).join(" "):"None",f=t.companyTags&&t.companyTags.length>0?`
## Companies

${t.companyTags.map(s=>`\`${s}\``).join(" ")}
`:"",g=e.notes?`
## Approach

${e.notes}
`:"",h=e.complexity?`
## Complexity

${e.complexity}
`:"",u=t.description?`
## Problem Statement

${t.description}
`:"",y=e.complexity?W(e.code,e.complexity,e.langSlug):e.code;return`# LeetCode #${t.number} - ${t.title}

- **Difficulty:** ${t.difficulty}
- **Language:** ${n}
- **Runtime:** ${o||"N/A"}
- **Memory:** ${a||"N/A"}
- **Date:** ${i}
- **Problem Link:** [LeetCode](${t.url})
- **Topics:** ${d}
${f}${g}${h}${u}
## Solution

\`\`\`${j(e.langSlug).monacoLanguage}
${y}
\`\`\`
`}function se(e,t,n){const{problem:o,language:a}=t,r=o.difficulty==="Easy"?"🟢":o.difficulty==="Medium"?"🟡":o.difficulty==="Hard"?"🔴":"⚪",i=`| ${o.number} | [${o.title}](${o.url}) | ${r} ${o.difficulty} | ${a} | [Solution](${n}) |`,d=`# LeetCode Solutions

Automatically synchronized from LeetCode via **LeetPush**.

| # | Problem | Difficulty | Language | Solution |
|---|---------|------------|----------|----------|`;if(!e||!e.includes("| # | Problem |"))return`${d}
${i}
`;const f=e.split(`
`),g=new RegExp(`\\|\\s*${o.number}\\s*\\|`),h=f.findIndex(y=>g.test(y));if(h!==-1)return f[h]=i,f.join(`
`);let u=-1;for(let y=0;y<f.length;y++){const p=f[y].match(/^\|\s*(\d+)\s*\|/);if(p&&p[1]&&parseInt(p[1],10)>o.number){u=y;break}}return u!==-1?(f.splice(u,0,i),f.join(`
`)):`${e.trim()}
${i}
`}function le(e,t){const{problem:n}=e,o=(t.baseDirectory||"solutions").replace(/\/+$/,""),a=`${B(n.number)}-${D(n.slug||n.title)}`;if(e.contestSlug&&t.enableContestFolder!==!1)return`contests/${D(e.contestSlug)}/${a}`;switch(t.folderStructure){case"difficulty":return`${o}/${n.difficulty.toLowerCase()}/${a}`;case"topic":{const r=n.topics[0]?D(n.topics[0]):"uncategorized";return`${o}/${r}/${a}`}default:return`${o}/${a}`}}function ce(e,t,n,o){const{problem:a,language:r}=t;let i=Y(e||"LeetCode #{number} - {title} [{language}]",{number:a.number,title:a.title,slug:a.slug,language:r,filename:n});return o.coAuthorName&&o.coAuthorEmail&&(i+=`

Co-authored-by: ${o.coAuthorName} <${o.coAuthorEmail}>`),i}async function C(e,t){var y;const{problem:n,language:o,submissionId:a}=e;if(l.info(`Starting sync for #${n.number} ${n.title} (${a})`),await G(a))return l.info(`Submission #${a} is already marked as synced in local database`),{status:"skipped",path:""};if(!t.token||!t.repository){const s="GitHub is not configured. Missing personal access token or repository name.";return l.error(s),await x(e,"",s),{status:"failed",path:"",error:s}}const[r,i]=t.repository.split("/");if(!r||!i){const s=`Invalid repository format "${t.repository}". Expected "owner/repo".`;return l.error(s),await x(e,"",s),{status:"failed",path:"",error:s}}const d=new O(t.token),f=j(e.langSlug),g=ne(e.langSlug),h=le(e,t);let u=`${h}/${g}`;if(t.fileNamingTemplate&&t.fileNamingTemplate!=="{padded_number}-{slug}/{filename}"){const s=Y(t.fileNamingTemplate,{number:n.number,title:n.title,slug:n.slug,language:o,filename:g});u=`${(t.baseDirectory||"solutions").replace(/\/+$/,"")}/${s}`}try{const s=await d.getFile(r,i,u,t.branch);let p;if(s){if(U(s.content).trim()===e.code.trim())return l.info(`File ${u} already exists with identical content on GitHub. Skipping.`),await L(a),await M(e,u,"skipped"),{status:"skipped",path:u};const c=u.split(".").pop()??"",b=f.extension.replace(".","");if(c.toLowerCase()===b.toLowerCase()){if(t.duplicateStrategy==="skip")return l.info(`Solution exists and strategy is "skip". Skipping ${u}.`),await L(a),await M(e,u,"skipped"),{status:"skipped",path:u};if(t.duplicateStrategy==="overwrite")l.info(`Overwriting existing solution at ${u}.`),p=s.sha;else if(t.duplicateStrategy==="version"){const A=f.extension,q=`${g.replace(A,"")}_${Date.now()}${A}`;u=`${h}/${q}`,l.info(`Creating versioned solution at ${u}.`)}}else l.info(`Different language detected (existing: .${c}, new: .${b}). Creating alongside.`)}const S=e.complexity?W(e.code,e.complexity,e.langSlug):e.code,P=ce(t.commitMessageTemplate,e,g,t);l.info(`Pushing solution code to ${r}/${i}/${u}`);const w=await d.createOrUpdateFile({owner:r,repo:i,path:u,content:S,message:P,branch:t.branch,sha:p});if(t.generateProblemReadme!==!1)try{const m=`${h}/README.md`,c=await d.getFile(r,i,m,t.branch),b=ie(e);await d.createOrUpdateFile({owner:r,repo:i,path:m,content:b,message:`Docs: LeetCode #${n.number} - ${n.title} README`,branch:t.branch,sha:c==null?void 0:c.sha})}catch(m){l.warn("Failed to push problem README (non-fatal)",m)}if(t.updateGlobalReadme)try{const m="README.md",c=await d.getFile(r,i,m,t.branch),b=c?U(c.content):"",I=se(b,e,u);await d.createOrUpdateFile({owner:r,repo:i,path:m,content:I,message:`Docs: update solutions table for #${n.number} ${n.title}`,branch:t.branch,sha:c==null?void 0:c.sha})}catch(m){l.warn("Failed to update global README table (non-fatal)",m)}if(t.enableWorkflowGeneration){const m=`${r}/${i}`;await K(m)||(await oe({token:t.token,owner:r,repo:i,branch:t.branch}),await z(m))}return await L(a),await M(e,u,"synced"),await J(),{status:"synced",path:u,commitUrl:(y=w==null?void 0:w.commit)==null?void 0:y.html_url}}catch(s){const p=(s==null?void 0:s.message)||"Unknown GitHub API error";return l.error(`Sync failed for #${n.number}:`,p),await x(e,u,p),await V(),{status:"failed",path:u,error:p}}}async function M(e,t,n){const o={submissionId:e.submissionId,problemSlug:e.problem.slug,problemNumber:e.problem.number,problemTitle:e.problem.title,difficulty:e.problem.difficulty,language:e.language,githubPath:t,syncedAt:Date.now(),status:n,notes:e.notes};await F(o)}async function x(e,t,n){const o={submissionId:e.submissionId,problemSlug:e.problem.slug,problemNumber:e.problem.number,problemTitle:e.problem.title,difficulty:e.problem.difficulty,language:e.language,githubPath:t,syncedAt:Date.now(),status:"failed",error:n};await F(o)}const R="LEETPUSH_PROCESS_PENDING_QUEUE",ue=5;chrome.runtime.onInstalled.addListener(async e=>{l.info(`LeetPush installed/updated: ${e.reason}`),await chrome.alarms.clear(R),chrome.alarms.create(R,{periodInMinutes:5})});chrome.alarms.onAlarm.addListener(async e=>{e.name===R&&(l.debug("Running scheduled pending sync queue processor"),await Q())});function $(e,t,n=!1){try{chrome.notifications.create({type:"basic",iconUrl:"icons/icon48.png",title:e,message:t,priority:n?2:1})}catch(o){l.warn("Could not display Chrome notification",o)}}chrome.runtime.onMessage.addListener((e,t,n)=>((async()=>{switch(e.type){case"SUBMISSION_ACCEPTED":{const a=e.payload;return await de(a.submission)}case"MANUAL_SYNC":return await me();case"INITIAL_SYNC":{const a=e.payload;return await fe(a.limit)}case"GET_STATUS":return await te();case"GET_PENDING":return await _();case"DISMISS_PENDING":{const{submissionId:a}=e.payload;return await T(a),{success:!0}}case"RETRY_PENDING":{const{submissionId:a}=e.payload;return await pe(a)}case"SKIP_PROBLEM":{const{slug:a}=e.payload;return await ee(a),l.info(`Problem "${a}" added to skip list`),{success:!0}}case"UNSKIP_PROBLEM":{const{slug:a}=e.payload;return await Z(a),l.info(`Problem "${a}" removed from skip list`),{success:!0}}case"UPDATE_SUBMISSION_NOTE":{const{submissionId:a,notes:r,complexity:i}=e.payload;return await X(a,{notes:r}),l.info(`Saved note for submission #${a}`),{success:!0,submissionId:a,notes:r,complexity:i}}default:return l.warn(`Unknown message type: ${e.type}`),{error:"Unknown message type"}}})().then(a=>{try{n(a)}catch{}}).catch(a=>{l.error("Unhandled error in background message handler",a);try{n({error:(a==null?void 0:a.message)||"Internal error"})}catch{}}),!0));async function de(e){if(await H(e.problem.slug))return l.info(`Problem "${e.problem.slug}" is on the skip list. Ignoring submission.`),{status:"skipped",path:"",error:"Problem is on the skip list"};const t=await E();if(!t||!t.token||!t.repository){const o="GitHub is not connected. Please connect in LeetPush settings.";return l.warn(o),$("LeetPush – GitHub Not Connected",o,!0),await N({submission:e,attemptCount:0,lastAttemptAt:Date.now(),nextRetryAt:Date.now()+60*1e3,error:o}),{status:"failed",path:"",error:o}}const n=await C(e,t);return n.status==="synced"?$("LeetPush – Solved & Pushed! ✓",`#${e.problem.number} ${e.problem.title} [${e.language}] pushed to ${t.repository}`):n.status==="skipped"?$("LeetPush – Already Exists",`Solution for #${e.problem.number} ${e.problem.title} is already up-to-date on GitHub.`):n.status==="failed"&&($("LeetPush – Sync Failed ✕",`Failed to sync #${e.problem.number} ${e.problem.title}: ${n.error}`,!0),await N({submission:e,attemptCount:1,lastAttemptAt:Date.now(),nextRetryAt:Date.now()+2*60*1e3,error:n.error})),n}async function Q(){const e=await _();if(e.length===0)return{processed:0,succeeded:0};const t=await E();if(!t||!t.token||!t.repository)return l.debug("Pending queue: GitHub not configured yet"),{processed:0,succeeded:0};const n=Date.now();let o=0,a=0;for(const r of e){if(n<r.nextRetryAt)continue;o++,l.info(`Retrying pending submission #${r.submission.submissionId} (attempt ${r.attemptCount+1})`);const i=await C(r.submission,t);if(i.status==="synced"||i.status==="skipped")a++,await T(r.submission.submissionId),l.info(`Pending submission #${r.submission.submissionId} resolved (${i.status})`);else{const d=r.attemptCount+1;if(d>=ue)l.error(`Max retries reached for #${r.submission.submissionId}. Dropping from queue.`),await T(r.submission.submissionId);else{const f=Math.pow(2,d)*60*1e3;await v(r.submission.submissionId,{attemptCount:d,lastAttemptAt:n,nextRetryAt:n+f,error:i.error})}}}return{processed:o,succeeded:a}}async function me(){return l.info("Manual sync triggered"),await Q()}async function pe(e){const n=(await _()).find(r=>r.submission.submissionId===e);if(!n)return{status:"failed",path:"",error:"Item not found in pending queue"};const o=await E();if(!o||!o.token||!o.repository)return{status:"failed",path:"",error:"GitHub not configured"};const a=await C(n.submission,o);if(a.status==="synced"||a.status==="skipped")await T(e),$("LeetPush – Retry Succeeded ✓",`#${n.submission.problem.number} ${n.submission.problem.title} synced successfully.`);else{const r=n.attemptCount+1;await v(e,{attemptCount:r,lastAttemptAt:Date.now(),nextRetryAt:Date.now()+60*1e3,error:a.error})}return a}async function fe(e){var f,g,h,u,y;const t=await E();if(!t||!t.token||!t.repository)throw new Error("GitHub is not configured. Cannot perform initial sync.");const n=e==="all"?1e3:e;l.info(`Starting initial batch sync (limit: ${e})`);const o=`
    query recentAcSubmissions($limit: Int!) {
      recentAcSubmissionList(limit: $limit) {
        id
        title
        titleSlug
        timestamp
      }
    }
  `;let a=[];try{const s=await fetch("https://leetcode.com/graphql",{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({query:o,variables:{limit:n}})});if(s.ok){const p=await s.json();a=((f=p==null?void 0:p.data)==null?void 0:f.recentAcSubmissionList)||[]}}catch(s){throw l.error("Failed to fetch recent submissions from LeetCode GraphQL",s),new Error("Could not retrieve recent submissions from LeetCode. Ensure you are logged into LeetCode.")}let r=0,i=0,d=0;for(const s of a){const p=String(s.id);if(await G(p)){i++;continue}if(await H(s.titleSlug)){i++;continue}try{const P=await fetch("https://leetcode.com/graphql",{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({query:`
        query submissionDetail($submissionId: Int!) {
          submissionDetail(submissionId: $submissionId) {
            code
            runtimeDisplay
            memoryDisplay
            lang {
              name
              verboseName
            }
            question {
              questionFrontendId
              title
              titleSlug
              difficulty
              topicTags {
                name
              }
            }
          }
        }
      `,variables:{submissionId:parseInt(p,10)}})});if(!P.ok){d++;continue}const w=await P.json(),m=(g=w==null?void 0:w.data)==null?void 0:g.submissionDetail;if(!m||!m.code){d++;continue}const c=m.question,b={number:parseInt((c==null?void 0:c.questionFrontendId)||"0",10),title:(c==null?void 0:c.title)||s.title,slug:(c==null?void 0:c.titleSlug)||s.titleSlug,url:`https://leetcode.com/problems/${(c==null?void 0:c.titleSlug)||s.titleSlug}/`,difficulty:(c==null?void 0:c.difficulty)||"Unknown",topics:((c==null?void 0:c.topicTags)||[]).map(k=>k.name)},I={submissionId:p,problem:b,language:((h=m.lang)==null?void 0:h.verboseName)||((u=m.lang)==null?void 0:u.name)||"Text",langSlug:((y=m.lang)==null?void 0:y.name)||"",code:m.code,runtime:m.runtimeDisplay||"",memory:m.memoryDisplay||"",submittedAt:parseInt(s.timestamp,10)*1e3||Date.now()},A=await C(I,t);A.status==="synced"?r++:A.status==="skipped"?i++:d++,await new Promise(k=>setTimeout(k,400))}catch(S){l.warn(`Failed initial sync for submission #${p}`,S),d++}}return $("LeetPush – Initial Sync Complete",`Synced: ${r}, Skipped (Already Existed): ${i}, Failed: ${d}`),{synced:r,skipped:i,failed:d}}
