import{i as G,m as C,h as K,a as z,b as J,c as V,d as F,g as N,e as E,r as T,u as v,f as X,j as Z,k as ee,l as te,n as H,o as _}from"./chunks/storage-YeR1Sdfg.js";import{G as O,d as U}from"./chunks/github-api-DTZqlZEf.js";import{g as B,a as ne}from"./chunks/language-BFafBiqH.js";import{l}from"./chunks/logger-BKt1tnhk.js";function D(e){return e?e.toLowerCase().trim().replace(/[/\\:*?"<>|#]/g,"").replace(/[^\w\s-]/g,"").replace(/[\s_]+/g,"-").replace(/^-+|-+$/g,""):""}function j(e){return e<0?"0000":String(e).padStart(4,"0")}function Y(e,t){return e.replace(/\{number\}/g,String(t.number)).replace(/\{padded_number\}/g,j(t.number)).replace(/\{title\}/g,t.title).replace(/\{slug\}/g,t.slug).replace(/\{language\}/g,t.language).replace(/\{filename\}/g,t.filename||"")}function ae(){return`name: LeetPush – README Sync

on:
  push:
    branches: [ main, master ]
    paths:
      - 'solutions/**'
      - 'contests/**'

jobs:
  verify-solutions:
    name: Verify Solutions Index
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Count solution files
        id: count
        run: |
          TOTAL=$(find solutions contests -type f \\( -name "*.py" -o -name "*.java" -o -name "*.cpp" -o -name "*.ts" -o -name "*.go" -o -name "*.rs" -o -name "*.js" -o -name "*.c" -o -name "*.cs" \\) 2>/dev/null | wc -l)
          echo "total=\${TOTAL}" >> "\${GITHUB_OUTPUT}"

      - name: Post summary
        run: |
          echo "## LeetPush Solution Summary" >> $GITHUB_STEP_SUMMARY
          echo "" >> $GITHUB_STEP_SUMMARY
          echo "✅ \${{ steps.count.outputs.total }} solution files tracked." >> $GITHUB_STEP_SUMMARY
          echo "" >> $GITHUB_STEP_SUMMARY
          echo "_Automatically maintained by [LeetPush](https://github.com/Iamudt19/Chaptr)_" >> $GITHUB_STEP_SUMMARY
`}async function oe(e){const{token:t,owner:n,repo:o,branch:a}=e,r=new O(t),s=".github/workflows/leetpush-sync.yml";try{const d=await r.getFile(n,o,s,a),f=ae();await r.createOrUpdateFile({owner:n,repo:o,path:s,content:f,message:"ci: add LeetPush solution tracking workflow",branch:a,sha:d==null?void 0:d.sha}),l.info(`GitHub Actions workflow generated at ${s}`)}catch(d){l.warn("Failed to generate GitHub Actions workflow (non-fatal)",d)}}function re(e,t){const n=t.toLowerCase();return`${n==="python"||n==="python3"||n==="ruby"||n==="elixir"?"#":n==="sql"?"--":"//"} ${e}
`}function W(e,t,n){return!t||e.trimStart().startsWith("// Time:")||e.trimStart().startsWith("# Time:")?e:`${re(t,n)}${e}`}function ie(e){const{problem:t,language:n,runtime:o,memory:a,submittedAt:r}=e,s=new Date(r).toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"}),d=t.topics.length>0?t.topics.map(i=>`\`${i}\``).join(" "):"None",f=t.companyTags&&t.companyTags.length>0?`
## Companies

${t.companyTags.map(i=>`\`${i}\``).join(" ")}
`:"",y=e.notes?`
## Approach

${e.notes}
`:"",h=e.complexity?`
## Complexity

${e.complexity}
`:"",u=t.description?`
## Problem Statement

${t.description}
`:"",g=e.complexity?W(e.code,e.complexity,e.langSlug):e.code;return`# LeetCode #${t.number} - ${t.title}

- **Difficulty:** ${t.difficulty}
- **Language:** ${n}
- **Runtime:** ${o||"N/A"}
- **Memory:** ${a||"N/A"}
- **Date:** ${s}
- **Problem Link:** [LeetCode](${t.url})
- **Topics:** ${d}
${f}${y}${h}${u}
## Solution

\`\`\`${B(e.langSlug).monacoLanguage}
${g}
\`\`\`
`}function se(e,t,n){const{problem:o,language:a}=t,r=o.difficulty==="Easy"?"🟢":o.difficulty==="Medium"?"🟡":o.difficulty==="Hard"?"🔴":"⚪",s=`| ${o.number} | [${o.title}](${o.url}) | ${r} ${o.difficulty} | ${a} | [Solution](${n}) |`,d=`# LeetCode Solutions

Automatically synchronized from LeetCode via **LeetPush**.

| # | Problem | Difficulty | Language | Solution |
|---|---------|------------|----------|----------|`;if(!e||!e.includes("| # | Problem |"))return`${d}
${s}
`;const f=e.split(`
`),y=new RegExp(`\\|\\s*${o.number}\\s*\\|`),h=f.findIndex(g=>y.test(g));if(h!==-1)return f[h]=s,f.join(`
`);let u=-1;for(let g=0;g<f.length;g++){const p=f[g].match(/^\|\s*(\d+)\s*\|/);if(p&&p[1]&&parseInt(p[1],10)>o.number){u=g;break}}return u!==-1?(f.splice(u,0,s),f.join(`
`)):`${e.trim()}
${s}
`}function le(e,t){const{problem:n}=e,o=(t.baseDirectory||"solutions").replace(/\/+$/,""),a=`${j(n.number)}-${D(n.slug||n.title)}`;if(e.contestSlug&&t.enableContestFolder!==!1)return`contests/${D(e.contestSlug)}/${a}`;switch(t.folderStructure){case"difficulty":return`${o}/${n.difficulty.toLowerCase()}/${a}`;case"topic":{const r=n.topics[0]?D(n.topics[0]):"uncategorized";return`${o}/${r}/${a}`}default:return`${o}/${a}`}}function ce(e,t,n,o){const{problem:a,language:r}=t;let s=Y(e||"LeetCode #{number} - {title} [{language}]",{number:a.number,title:a.title,slug:a.slug,language:r,filename:n});return o.coAuthorName&&o.coAuthorEmail&&(s+=`

Co-authored-by: ${o.coAuthorName} <${o.coAuthorEmail}>`),s}async function L(e,t){var g;const{problem:n,language:o,submissionId:a}=e;if(l.info(`Starting sync for #${n.number} ${n.title} (${a})`),await G(a))return l.info(`Submission #${a} is already marked as synced in local database`),{status:"skipped",path:""};if(!t.token||!t.repository){const i="GitHub is not configured. Missing personal access token or repository name.";return l.error(i),await x(e,"",i),{status:"failed",path:"",error:i}}const[r,s]=t.repository.split("/");if(!r||!s){const i=`Invalid repository format "${t.repository}". Expected "owner/repo".`;return l.error(i),await x(e,"",i),{status:"failed",path:"",error:i}}const d=new O(t.token),f=B(e.langSlug),y=ne(e.langSlug),h=le(e,t);let u=`${h}/${y}`;if(t.fileNamingTemplate&&t.fileNamingTemplate!=="{padded_number}-{slug}/{filename}"){const i=Y(t.fileNamingTemplate,{number:n.number,title:n.title,slug:n.slug,language:o,filename:y});u=`${(t.baseDirectory||"solutions").replace(/\/+$/,"")}/${i}`}try{const i=await d.getFile(r,s,u,t.branch);let p;if(i){if(U(i.content).trim()===e.code.trim())return l.info(`File ${u} already exists with identical content on GitHub. Skipping.`),await C(a),await M(e,u,"skipped"),{status:"skipped",path:u};const c=u.split(".").pop()??"",b=f.extension.replace(".","");if(c.toLowerCase()===b.toLowerCase()){if(t.duplicateStrategy==="skip")return l.info(`Solution exists and strategy is "skip". Skipping ${u}.`),await C(a),await M(e,u,"skipped"),{status:"skipped",path:u};if(t.duplicateStrategy==="overwrite")l.info(`Overwriting existing solution at ${u}.`),p=i.sha;else if(t.duplicateStrategy==="version"){const P=f.extension,Q=`${y.replace(P,"")}_${Date.now()}${P}`;u=`${h}/${Q}`,l.info(`Creating versioned solution at ${u}.`)}}else l.info(`Different language detected (existing: .${c}, new: .${b}). Creating alongside.`)}const S=e.complexity?W(e.code,e.complexity,e.langSlug):e.code,A=ce(t.commitMessageTemplate,e,y,t);l.info(`Pushing solution code to ${r}/${s}/${u}`);const w=await d.createOrUpdateFile({owner:r,repo:s,path:u,content:S,message:A,branch:t.branch,sha:p});if(t.generateProblemReadme!==!1)try{const m=`${h}/README.md`,c=await d.getFile(r,s,m,t.branch),b=ie(e);await d.createOrUpdateFile({owner:r,repo:s,path:m,content:b,message:`Docs: LeetCode #${n.number} - ${n.title} README`,branch:t.branch,sha:c==null?void 0:c.sha})}catch(m){l.warn("Failed to push problem README (non-fatal)",m)}if(t.updateGlobalReadme)try{const m="README.md",c=await d.getFile(r,s,m,t.branch),b=c?U(c.content):"",k=se(b,e,u);await d.createOrUpdateFile({owner:r,repo:s,path:m,content:k,message:`Docs: update solutions table for #${n.number} ${n.title}`,branch:t.branch,sha:c==null?void 0:c.sha})}catch(m){l.warn("Failed to update global README table (non-fatal)",m)}if(t.enableWorkflowGeneration){const m=`${r}/${s}`;await K(m)||(await oe({token:t.token,owner:r,repo:s,branch:t.branch}),await z(m))}return await C(a),await M(e,u,"synced"),await J(),{status:"synced",path:u,commitUrl:(g=w==null?void 0:w.commit)==null?void 0:g.html_url}}catch(i){const p=(i==null?void 0:i.message)||"Unknown GitHub API error";return l.error(`Sync failed for #${n.number}:`,p),await x(e,u,p),await V(),{status:"failed",path:u,error:p}}}async function M(e,t,n){const o={submissionId:e.submissionId,problemSlug:e.problem.slug,problemNumber:e.problem.number,problemTitle:e.problem.title,difficulty:e.problem.difficulty,language:e.language,githubPath:t,syncedAt:Date.now(),status:n,notes:e.notes};await F(o)}async function x(e,t,n){const o={submissionId:e.submissionId,problemSlug:e.problem.slug,problemNumber:e.problem.number,problemTitle:e.problem.title,difficulty:e.problem.difficulty,language:e.language,githubPath:t,syncedAt:Date.now(),status:"failed",error:n};await F(o)}const R="LEETPUSH_PROCESS_PENDING_QUEUE",ue=5;chrome.runtime.onInstalled.addListener(async e=>{l.info(`LeetPush installed/updated: ${e.reason}`),await chrome.alarms.clear(R),chrome.alarms.create(R,{periodInMinutes:5})});chrome.alarms.onAlarm.addListener(async e=>{e.name===R&&(l.debug("Running scheduled pending sync queue processor"),await q())});function $(e,t,n=!1){try{chrome.notifications.create({type:"basic",iconUrl:"icons/icon48.png",title:e,message:t,priority:n?2:1})}catch(o){l.warn("Could not display Chrome notification",o)}}chrome.runtime.onMessage.addListener((e,t,n)=>((async()=>{switch(e.type){case"SUBMISSION_ACCEPTED":{const a=e.payload;return await de(a.submission)}case"MANUAL_SYNC":return await me();case"INITIAL_SYNC":{const a=e.payload;return await fe(a.limit)}case"GET_STATUS":return await te();case"GET_PENDING":return await N();case"DISMISS_PENDING":{const{submissionId:a}=e.payload;return await T(a),{success:!0}}case"RETRY_PENDING":{const{submissionId:a}=e.payload;return await pe(a)}case"SKIP_PROBLEM":{const{slug:a}=e.payload;return await ee(a),l.info(`Problem "${a}" added to skip list`),{success:!0}}case"UNSKIP_PROBLEM":{const{slug:a}=e.payload;return await Z(a),l.info(`Problem "${a}" removed from skip list`),{success:!0}}case"UPDATE_SUBMISSION_NOTE":{const{submissionId:a,notes:r,complexity:s}=e.payload;return await X(a,{notes:r}),l.info(`Saved note for submission #${a}`),{success:!0,submissionId:a,notes:r,complexity:s}}default:return l.warn(`Unknown message type: ${e.type}`),{error:"Unknown message type"}}})().then(a=>{try{n(a)}catch{}}).catch(a=>{const r=(a==null?void 0:a.message)||String(a);l.warn("Background message handler warning:",r);try{n({error:r})}catch{}}),!0));async function de(e){if(await H(e.problem.slug))return l.info(`Problem "${e.problem.slug}" is on the skip list. Ignoring submission.`),{status:"skipped",path:"",error:"Problem is on the skip list"};const t=await E();if(!t||!t.token||!t.repository){const o="GitHub is not connected. Please connect in LeetPush settings.";return l.warn(o),$("LeetPush – GitHub Not Connected",o,!0),await _({submission:e,attemptCount:0,lastAttemptAt:Date.now(),nextRetryAt:Date.now()+60*1e3,error:o}),{status:"failed",path:"",error:o}}const n=await L(e,t);return n.status==="synced"?$("LeetPush – Solved & Pushed! ✓",`#${e.problem.number} ${e.problem.title} [${e.language}] pushed to ${t.repository}`):n.status==="skipped"?$("LeetPush – Already Exists",`Solution for #${e.problem.number} ${e.problem.title} is already up-to-date on GitHub.`):n.status==="failed"&&($("LeetPush – Sync Failed ✕",`Failed to sync #${e.problem.number} ${e.problem.title}: ${n.error}`,!0),await _({submission:e,attemptCount:1,lastAttemptAt:Date.now(),nextRetryAt:Date.now()+2*60*1e3,error:n.error})),n}async function q(){const e=await N();if(e.length===0)return{processed:0,succeeded:0};const t=await E();if(!t||!t.token||!t.repository)return l.debug("Pending queue: GitHub not configured yet"),{processed:0,succeeded:0};const n=Date.now();let o=0,a=0;for(const r of e){if(n<r.nextRetryAt)continue;o++,l.info(`Retrying pending submission #${r.submission.submissionId} (attempt ${r.attemptCount+1})`);const s=await L(r.submission,t);if(s.status==="synced"||s.status==="skipped")a++,await T(r.submission.submissionId),l.info(`Pending submission #${r.submission.submissionId} resolved (${s.status})`);else{const d=r.attemptCount+1;if(d>=ue)l.error(`Max retries reached for #${r.submission.submissionId}. Dropping from queue.`),await T(r.submission.submissionId);else{const f=Math.pow(2,d)*60*1e3;await v(r.submission.submissionId,{attemptCount:d,lastAttemptAt:n,nextRetryAt:n+f,error:s.error})}}}return{processed:o,succeeded:a}}async function me(){return l.info("Manual sync triggered"),await q()}async function pe(e){const n=(await N()).find(r=>r.submission.submissionId===e);if(!n)return{status:"failed",path:"",error:"Item not found in pending queue"};const o=await E();if(!o||!o.token||!o.repository)return{status:"failed",path:"",error:"GitHub not configured"};const a=await L(n.submission,o);if(a.status==="synced"||a.status==="skipped")await T(e),$("LeetPush – Retry Succeeded ✓",`#${n.submission.problem.number} ${n.submission.problem.title} synced successfully.`);else{const r=n.attemptCount+1;await v(e,{attemptCount:r,lastAttemptAt:Date.now(),nextRetryAt:Date.now()+60*1e3,error:a.error})}return a}async function fe(e){var f,y,h,u,g;const t=await E();if(!t||!t.token||!t.repository){const i="GitHub is not configured. Please connect your GitHub account in settings.";return l.warn(i),$("LeetPush – Setup Required",i,!0),{synced:0,skipped:0,failed:0,error:i}}const n=e==="all"?1e3:e;l.info(`Starting initial batch sync (limit: ${e})`);const o=`
    query recentAcSubmissions($limit: Int!) {
      recentAcSubmissionList(limit: $limit) {
        id
        title
        titleSlug
        timestamp
      }
    }
  `;let a=[];try{const i=await fetch("https://leetcode.com/graphql",{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({operationName:"recentAcSubmissions",query:o,variables:{limit:n}})});if(i.ok){const p=await i.json();a=((f=p==null?void 0:p.data)==null?void 0:f.recentAcSubmissionList)||[]}}catch(i){throw l.error("Failed to fetch recent submissions from LeetCode GraphQL",i),new Error("Could not retrieve recent submissions from LeetCode. Ensure you are logged into LeetCode.")}let r=0,s=0,d=0;for(const i of a){const p=String(i.id);if(await G(p)){s++;continue}if(await H(i.titleSlug)){s++;continue}try{const A=await fetch("https://leetcode.com/graphql",{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({operationName:"submissionDetail",query:`
        query submissionDetail($submissionId: Int!) {
          submissionDetail(submissionId: $submissionId) {
            code
            runtimeDisplay
            memoryDisplay
            lang {
              name
              verboseName
            }
            question {
              questionFrontendId
              title
              titleSlug
              difficulty
              topicTags {
                name
              }
            }
          }
        }
      `,variables:{submissionId:parseInt(p,10)}})});if(!A.ok){d++;continue}const w=await A.json(),m=(y=w==null?void 0:w.data)==null?void 0:y.submissionDetail;if(!m||!m.code){d++;continue}const c=m.question,b={number:parseInt((c==null?void 0:c.questionFrontendId)||"0",10),title:(c==null?void 0:c.title)||i.title,slug:(c==null?void 0:c.titleSlug)||i.titleSlug,url:`https://leetcode.com/problems/${(c==null?void 0:c.titleSlug)||i.titleSlug}/`,difficulty:(c==null?void 0:c.difficulty)||"Unknown",topics:((c==null?void 0:c.topicTags)||[]).map(I=>I.name)},k={submissionId:p,problem:b,language:((h=m.lang)==null?void 0:h.verboseName)||((u=m.lang)==null?void 0:u.name)||"Text",langSlug:((g=m.lang)==null?void 0:g.name)||"",code:m.code,runtime:m.runtimeDisplay||"",memory:m.memoryDisplay||"",submittedAt:parseInt(i.timestamp,10)*1e3||Date.now()},P=await L(k,t);P.status==="synced"?r++:P.status==="skipped"?s++:d++,await new Promise(I=>setTimeout(I,400))}catch(S){l.warn(`Failed initial sync for submission #${p}`,S),d++}}return $("LeetPush – Initial Sync Complete",`Synced: ${r}, Skipped (Already Existed): ${s}, Failed: ${d}`),{synced:r,skipped:s,failed:d}}
