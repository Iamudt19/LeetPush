(function() {
  "use strict";
  (function() {
    const win = window;
    if (win.__LEETPUSH_INTERCEPTOR_INSTALLED__) return;
    win.__LEETPUSH_INTERCEPTOR_INSTALLED__ = true;
    console.info("[LeetPush] Interceptor installed in MAIN world context");
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
      const response = await originalFetch.apply(this, args);
      try {
        const url = typeof args[0] === "string" ? args[0] : args[0] && args[0].url ? args[0].url : "";
        if (url.includes("/submissions/detail/") && url.includes("/check/")) {
          const clone = response.clone();
          clone.json().then((data) => {
            if (data && (data.status_msg === "Accepted" || data.state === "SUCCESS" || data.status_code === 10)) {
              window.dispatchEvent(
                new CustomEvent("LEETPUSH_SUBMISSION_EVENT", {
                  detail: {
                    source: "fetch_check",
                    url,
                    data
                  }
                })
              );
            }
          }).catch(() => {
          });
        }
        if (url.includes("/graphql") && args[1] && typeof args[1].body === "string") {
          const bodyStr = args[1].body;
          if (bodyStr.includes("submissionDetails") || bodyStr.includes("submitCode") || bodyStr.includes("checkSubmissionStatus")) {
            const clone = response.clone();
            clone.json().then((resJson) => {
              if (resJson && resJson.data) {
                window.dispatchEvent(
                  new CustomEvent("LEETPUSH_SUBMISSION_EVENT", {
                    detail: {
                      source: "fetch_graphql",
                      url,
                      data: resJson.data
                    }
                  })
                );
              }
            }).catch(() => {
            });
          }
        }
      } catch {
      }
      return response;
    };
    const originalXhrOpen = XMLHttpRequest.prototype.open;
    const originalXhrSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__leetpush_url = String(url);
      return originalXhrOpen.apply(this, [method, url, ...rest]);
    };
    XMLHttpRequest.prototype.send = function(...args) {
      this.addEventListener("load", function() {
        try {
          const url = this.__leetpush_url || "";
          if (url.includes("/submissions/detail/") && url.includes("/check/")) {
            const data = JSON.parse(this.responseText);
            if (data && (data.status_msg === "Accepted" || data.state === "SUCCESS" || data.status_code === 10)) {
              window.dispatchEvent(
                new CustomEvent("LEETPUSH_SUBMISSION_EVENT", {
                  detail: {
                    source: "xhr_check",
                    url,
                    data
                  }
                })
              );
            }
          }
        } catch {
        }
      });
      return originalXhrSend.apply(this, args);
    };
  })();
})();
