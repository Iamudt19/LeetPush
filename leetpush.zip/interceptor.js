(function() {
  "use strict";
  (function() {
    const win = window;
    if (win.__LEETPUSH_INTERCEPTOR_INSTALLED__) return;
    win.__LEETPUSH_INTERCEPTOR_INSTALLED__ = true;
    console.info("[LeetPush] Interceptor installed in MAIN world context");
    function updateHiddenDomElement(id, value) {
      try {
        let el = document.getElementById(id);
        if (!el) {
          el = document.createElement("textarea");
          el.id = id;
          el.style.display = "none";
          (document.body || document.documentElement).appendChild(el);
        }
        el.value = value;
      } catch {
      }
    }
    function getMonacoCodeFromMainWorld() {
      var _a, _b;
      try {
        if ((_b = (_a = win.monaco) == null ? void 0 : _a.editor) == null ? void 0 : _b.getModels) {
          const models = win.monaco.editor.getModels();
          for (const m of models) {
            const val = m.getValue();
            if (val && val.trim().length > 0) return val;
          }
        }
      } catch {
      }
      return "";
    }
    window.addEventListener("LEETPUSH_REQUEST_MONACO_CODE", () => {
      const code = getMonacoCodeFromMainWorld();
      if (code) {
        win.__LEETPUSH_LAST_SUBMITTED_CODE__ = code;
        updateHiddenDomElement("leetpush-monaco-code", code);
      }
      window.dispatchEvent(
        new CustomEvent("LEETPUSH_RESPONSE_MONACO_CODE", {
          detail: { code }
        })
      );
    });
    function extractSubmittedCodeFromBody(bodyStr) {
      var _a, _b;
      if (!bodyStr) return null;
      try {
        const str = typeof bodyStr === "string" ? bodyStr : "";
        if (!str) return null;
        const parsed = JSON.parse(str);
        const code = parsed.typed_code || parsed.code || ((_a = parsed.variables) == null ? void 0 : _a.code) || ((_b = parsed.variables) == null ? void 0 : _b.typed_code);
        if (typeof code === "string" && code.trim().length > 0) {
          return code;
        }
      } catch {
      }
      return null;
    }
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
      try {
        if (args[1] && args[1].body) {
          const capturedCode = extractSubmittedCodeFromBody(args[1].body);
          if (capturedCode) {
            win.__LEETPUSH_LAST_SUBMITTED_CODE__ = capturedCode;
            updateHiddenDomElement("leetpush-submitted-code", capturedCode);
          }
        }
      } catch {
      }
      const response = await originalFetch.apply(this, args);
      try {
        const url = typeof args[0] === "string" ? args[0] : args[0] && args[0].url ? args[0].url : "";
        if (url.includes("/submissions/detail/") && url.includes("/check/") && !url.includes("runcode")) {
          const clone = response.clone();
          clone.json().then((data) => {
            if (data && (data.status_msg === "Accepted" || data.state === "SUCCESS" || data.status_code === 10)) {
              if (!data.code && win.__LEETPUSH_LAST_SUBMITTED_CODE__) {
                data.code = win.__LEETPUSH_LAST_SUBMITTED_CODE__;
              } else if (!data.code) {
                data.code = getMonacoCodeFromMainWorld();
              }
              window.dispatchEvent(
                new CustomEvent("LEETPUSH_SUBMISSION_EVENT", {
                  detail: {
                    source: "fetch_check",
                    url,
                    data
                  }
                })
              );
            }
          }).catch(() => {
          });
        }
        if (url.includes("/graphql") && args[1] && typeof args[1].body === "string") {
          const bodyStr = args[1].body;
          if (bodyStr.includes("submissionDetails") || bodyStr.includes("submitCode") || bodyStr.includes("checkSubmissionStatus")) {
            const clone = response.clone();
            clone.json().then((resJson) => {
              if (resJson && resJson.data) {
                if (win.__LEETPUSH_LAST_SUBMITTED_CODE__ && !resJson.data.code) {
                  resJson.data.code = win.__LEETPUSH_LAST_SUBMITTED_CODE__;
                }
                window.dispatchEvent(
                  new CustomEvent("LEETPUSH_SUBMISSION_EVENT", {
                    detail: {
                      source: "fetch_graphql",
                      url,
                      data: resJson.data
                    }
                  })
                );
              }
            }).catch(() => {
            });
          }
        }
      } catch {
      }
      return response;
    };
    const originalXhrOpen = XMLHttpRequest.prototype.open;
    const originalXhrSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__leetpush_url = String(url);
      return originalXhrOpen.apply(this, [method, url, ...rest]);
    };
    XMLHttpRequest.prototype.send = function(...args) {
      try {
        if (args[0]) {
          const capturedCode = extractSubmittedCodeFromBody(args[0]);
          if (capturedCode) {
            win.__LEETPUSH_LAST_SUBMITTED_CODE__ = capturedCode;
            updateHiddenDomElement("leetpush-submitted-code", capturedCode);
          }
        }
      } catch {
      }
      this.addEventListener("load", function() {
        try {
          const url = this.__leetpush_url || "";
          if (url.includes("/submissions/detail/") && url.includes("/check/")) {
            const data = JSON.parse(this.responseText);
            if (data && (data.status_msg === "Accepted" || data.state === "SUCCESS" || data.status_code === 10)) {
              if (!data.code && win.__LEETPUSH_LAST_SUBMITTED_CODE__) {
                data.code = win.__LEETPUSH_LAST_SUBMITTED_CODE__;
              } else if (!data.code) {
                data.code = getMonacoCodeFromMainWorld();
              }
              window.dispatchEvent(
                new CustomEvent("LEETPUSH_SUBMISSION_EVENT", {
                  detail: {
                    source: "xhr_check",
                    url,
                    data
                  }
                })
              );
            }
          }
        } catch {
        }
      });
      return originalXhrSend.apply(this, args);
    };
  })();
})();
